package com.sag.bankapp.exception;


//author Dharmendra D - 

/*
 * this class handles authentication and session exception
 */
public class SessionException extends Exception
{
	private String errorMsg;

	public SessionException(String errorMsg)
	{
		this.errorMsg = errorMsg;
	}

	@Override
	public String getMessage()
	{
		return errorMsg;
	}
}

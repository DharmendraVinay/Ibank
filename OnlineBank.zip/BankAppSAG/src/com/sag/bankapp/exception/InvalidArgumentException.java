package com.sag.bankapp.exception;

//author Dharmendra D -
// this class generates exceptions when input or arguments are invalid
public class InvalidArgumentException extends Exception
{

	private String errorMsg;
	public InvalidArgumentException(String errorMsg){
		this.errorMsg = errorMsg;
	}
	@Override
	public String getMessage()
	{
		return errorMsg;
	}
	
}

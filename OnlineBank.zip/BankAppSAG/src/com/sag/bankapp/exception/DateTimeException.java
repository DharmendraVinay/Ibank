package com.sag.bankapp.exception;



//author Dharmendra D -

public class DateTimeException extends Exception
{
	private String errorMsg;

	public DateTimeException(String errorMsg)
	{
		this.errorMsg = errorMsg;
	}

	@Override
	public String getMessage()
	{
		return errorMsg;
	}
}

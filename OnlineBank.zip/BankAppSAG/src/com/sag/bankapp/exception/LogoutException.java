package com.sag.bankapp.exception;

//author Dharmendra D - 
public class LogoutException extends Exception
{
	private String errorMsg;

	public LogoutException(String errorMsg)
	{
		this.errorMsg = errorMsg;
	}

	@Override
	public String getMessage()
	{
		return errorMsg;
	}
}

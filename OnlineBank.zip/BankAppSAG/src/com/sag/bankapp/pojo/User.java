package com.sag.bankapp.pojo;


//author Dharmendra D - 
import java.sql.SQLException;
import java.util.Date;

public class User
{
	private int userId;
	private String userName;
	private String firstName;
	private String lastName;
	private Date DOB;

	private String email;
	private long number;
	private String houseNo;
	private String plotNo;
	private String street;
	private String city;
	private String state;
	
	public String getState()
	{
		return state;
	}

	public void setState(String state)
	{
		this.state = state;
	}




	public String getHouseNo()
	{
		return houseNo;
	}

	public void setHouseNo(String houseNo)
	{
		this.houseNo = houseNo;
	}

	public String getPlotNo()
	{
		return plotNo;
	}

	public void setPlotNo(String plotNo)
	{
		this.plotNo = plotNo;
	}

	public String getStreet()
	{
		return street;
	}

	public void setStreet(String street)
	{
		this.street = street;
	}

	public String getCity()
	{
		return city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}




	private String securityQuestion;
	private String securityAnswer;
	private String password;
	private long alternateNumber;
	
	public long getAlternateNumber()
	{
		return alternateNumber;
	}

	public void setAlternateNumber(long alternateNumber)
	{
		this.alternateNumber = alternateNumber;
	}

	public String getUserName()
	{
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public Date getDOB()
	{
		return DOB;
	}

	public void setDOB(Date dOB)
	{
		DOB = dOB;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public long getNumber()
	{
		return number;
	}

	public void setNumber(long number)
	{
		this.number = number;
	}

	

	public String getSecurityQuestion()
	{
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion)
	{
		this.securityQuestion = securityQuestion;
	}

	public String getSecurityAnswer()
	{
		return securityAnswer;
	}

	public void setSecurityAnswer(String securityAnswer)
	{
		this.securityAnswer = securityAnswer;
	}

	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	public int getUserId()
	{
		return userId;
	}

	public void setUserId(int userId)
	{
		this.userId = userId;
	}

	@Override
	public String toString()
	{
		return "User [userId=" + userId + ", userName=" + userName
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", DOB=" + DOB + ", email=" + email + ", number=" + number
				+ ", houseNo=" + houseNo + ", plotNo=" + plotNo + ", street="
				+ street + ", city=" + city + ", state=" + state
				+ ", securityQuestion=" + securityQuestion
				+ ", securityAnswer=" + securityAnswer + ", password="
				+ password + ", alternateNumber=" + alternateNumber + "]";
	}

	


	
	
	

}

package com.sag.bankapp.pojo;


//author Dharmendra D - 

public class Account
{
	private long accountNumber;
	private int userId;
	private int isActive;
	private int isLoggedIn;
	private int isBelowMinBal;
	private float accountBalnce;

	public long getAccountNumber()
	{
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber)
	{
		this.accountNumber = accountNumber;
	}

	public int getUserId()
	{
		return userId;
	}

	public void setUserId(int userId)
	{
		this.userId = userId;
	}

	public int getIsActive()
	{
		return isActive;
	}

	public void setIsActive(int isActive)
	{
		this.isActive = isActive;
	}

	public int getIsLoggedIn()
	{
		return isLoggedIn;
	}

	public void setIsLoggedIn(int isLoggedIn)
	{
		this.isLoggedIn = isLoggedIn;
	}

	public int getIsBelowMinBal()
	{
		return isBelowMinBal;
	}

	public void setIsBelowMinBal(int isBelowMinBal)
	{
		this.isBelowMinBal = isBelowMinBal;
	}

	public float getAccountBalnce()
	{
		return accountBalnce;
	}

	public void setAccountBalnce(float accountBalnce)
	{
		this.accountBalnce = accountBalnce;
	}

}

package com.sag.bankapp.pojo;


//author Dharmendra D -

public class PassBook
{
	public String dateTime;
	public String TOT;
	public int amount;
	public int currentBalance;

	public PassBook(String dateTime, String transactionType, int amount,
			int currentBalance)
	{
		super();
		this.dateTime = dateTime;
		this.TOT = transactionType;
		this.amount = amount;
		this.currentBalance = currentBalance;
	}

	public String getDateTime()
	{
		return dateTime;
	}

	public void setDateTime(String dateTime)
	{
		this.dateTime = dateTime;
	}

	public String getTOT()
	{
		return TOT;
	}

	public void setTOT(String TOT)
	{
		this.TOT = TOT;
	}

	public int getAmount()
	{
		return amount;
	}

	public void setAmount(int amount)
	{
		this.amount = amount;
	}

	public int getCurrentBalance()
	{
		return currentBalance;
	}

	public void setCurrentBalance(int currentBalance)
	{
		this.currentBalance = currentBalance;
	}

}

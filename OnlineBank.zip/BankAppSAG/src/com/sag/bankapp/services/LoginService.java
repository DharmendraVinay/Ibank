package com.sag.bankapp.services;

public class LoginService
{
	
	
	public  boolean validateUser(String username, String password){
		boolean status = false;
		
		
		return status;
	}
}

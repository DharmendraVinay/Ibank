package com.sag.bankapp.services;

import java.io.IOException;
import java.sql.SQLException;

import com.sag.bankapp.exception.InvalidArgumentException;
import com.sag.bankapp.exception.LogoutException;
import com.sag.bankapp.exception.MainPageException;
import com.sag.bankapp.exception.SessionException;

public interface NetworkResponse
{
	void networkCallBACK(int status, String statusMsg) throws SessionException, InvalidArgumentException, SQLException,MainPageException,LogoutException, IOException;
}

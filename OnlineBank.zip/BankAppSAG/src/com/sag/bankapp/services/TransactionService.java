package com.sag.bankapp.services;

import com.sag.bankapp.exception.InvalidArgumentException;

public class TransactionService
{

	public boolean trasnferFund(long destAccountNumber, String userId,
			long money) throws InvalidArgumentException
	{

		
		return true;
	}
}

package com.sag.bankapp.constants;

//author Dharmendra D - 

import static java.util.concurrent.TimeUnit.*;

public class BankAppConstants
{

	public static final int FORGOT_PASSWORD_OPTION = 3;
	public static final int EXIT_APP = 9;
	public static final int NEW_USER = 1;
	public static final int EXISTING_USER = 2;
	public static final int USER_ACTIVE_STATUS = 1;
	public static final int USER_INACTIVE_STATUS = 1;
	public static final int TRANSFER_FUND = 1;
	public static final int VIEW_PASSBOOK = 2;
	public static final int CHANGE_PASSWORD = 3;
	public static final int GENERATE_CUSTOM_PASSBOOK = 1;
	public static final int SUCCESSFUL_NETWORK_RESPONSE = 0;
	public static final int UNSUCCESSFUL_REQUEST = 1;
	public static final int TOTAL_LOGIN_ATTEMPTS = 3;
	public static final String WITHDRAW = "W";
	public static final int SUCCESS = 1;
	public static final int FAIL = 0;
	public static final String DEPOSIT = "D";
	public static final int WITHDRAW_CHOICE = 1;
	public static final int DEPOSIT_CHOICE = 2;
	public static final int TRANSFER_FUND_OPTION = 3;
	public static final int CHECK_BALANCE = 4;
	public static final int HOME_NAVIAGTE = 8;
	public static final int LOGOUT_CHOICE = 9;

	public final static String BANK_EMAIL = "dummy404singh@gmail.com";
	public final static String BANK_EMAIL_PASSWORD = "qwer2ASDF";

	// http://stackoverflow.com/questions/7080051/checking-if-difference-between-2-date-is-more-than-20-minutes
	public static long MAX_IDLE_DURATION = MILLISECONDS.convert(10, MINUTES);

}

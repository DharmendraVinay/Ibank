package com.sag.bankapp.constants;

//author Dharmendra D -
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.DatabaseUtils;
import com.sag.bankapp.util.NetworkUtils;
import com.sag.bankapp.util.StringUtility;

public class TransferFundView
{

	// private static long ID;
	private static IOUtils ioUtils;
	private static DatabaseUtils dbUtils;
	private static NetworkUtils networkUtils;
	private static StringUtility stringUtils;
	boolean isSpacePresent;
	static ResultSet rs;
	String Customers_EmialId = "alok.kumar@softwareag.com";
	String to = Customers_EmialId;
	// Sender's email ID needs to be mentioned
	static String from = "dummy404singh@gmail.com";

	final static String username = "dummy404singh@gmail.com";// change
																// accordingly
	final static String password = "qwer2ASDF";// change accordingly

	public TransferFundView()
	{
		ioUtils = new IOUtils();
		dbUtils = new DatabaseUtils();
		stringUtils = new StringUtility();
	}

	private static java.sql.Timestamp getCurrentTimeStamp()
	{

		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());
	}

	public static long withdraw(long amt, long ID)
	{
		Connection dbConnection = dbUtils.getDBConnection();
		int amt1 = 0;

		try
		{
			String sql = "SELECT ACCOUNT_BALANCE,IS_ACTIVE FROM ACCOUNT WHERE ACCOUNT_NUMBER=?";

			PreparedStatement pst = dbConnection.prepareStatement(sql);
			pst.setLong(1, ID);
			rs = pst.executeQuery();
			while (rs.next())
			{
				amt1 = rs.getInt(1);
				int active = rs.getInt(2);

				// TODO : set active while login ;
				if (amt1 < 100)
				{
					String sql2 = "UPDATE ACCOUNT SET IS_BELOW_MIN_BALANCE='1' WHERE ACCOUNT_NUMBER=?";
					PreparedStatement pst2 = dbConnection
							.prepareStatement(sql2);
					pst2.setLong(1, ID);
					int rowsUpdated = pst2.executeUpdate();

					if (rowsUpdated >= 1)
					{
						System.out.println("Maintain minimum balance");
					}

				}

				else if (amt > amt1)
				{
					System.out.println("No sufficient Balance");

				}

				else
				{
					String sql2 = "UPDATE ACCOUNT SET IS_BELOW_MIN_BALANCE='0' WHERE ACCOUNT_NUMBER=?";
					PreparedStatement pst1 = dbConnection
							.prepareStatement(sql2);
					pst1.setLong(1, ID);
					pst1.executeUpdate();

					long diff = (amt1 - amt);
					String sql3 = "UPDATE ACCOUNT SET ACCOUNT_BALANCE=? WHERE ACCOUNT_NUMBER=?";

					PreparedStatement pst2 = dbConnection
							.prepareStatement(sql3);
					pst2.setLong(1, diff);
					pst2.setLong(2, ID);

					pst2.executeQuery();

				}
			}

			/*
			 * //CREATE TABLE "TRANSACTION" ( "ACCOUNT_NUMBER" NUMBER(20,0),
			 * "DATE_AND_TIME" TIMESTAMP (6), "TYPE_OF_TRANS" VARCHAR2(40),
			 * "AMOUNT" NUMBER(10,0), "BALANCE" NUMBER(10,0), CONSTRAINT
			 * "PK_KEY3333" PRIMARY KEY ("ACCOUNT_NUMBER", "DATE_AND_TIME")
			 * ENABLE, FOREIGN KEY ("ACCOUNT_NUMBER") REFERENCES "ACCOUNT"
			 * ("ACCOUNT_NUMBER") ENABLE ) /
			 */

			String insert = "INSERT INTO TRANSACTION VALUES(?,?,?,?,?)";
			PreparedStatement ins1 = dbConnection.prepareStatement(insert);
			ins1.setLong(1, ID);// / get account number on login
			ins1.setTimestamp(2, getCurrentTimeStamp());
			ins1.setString(3, "W");
			ins1.setLong(4, amt);
			ins1.setLong(5, amt1 - amt);

			rs = ins1.executeQuery();

		} catch (SQLException e)
		{
			e.printStackTrace();

		}

		// NetworkUtils.sendEmail("nikeshsraj@gmail.com",
		// "Transaction successful","Transaction successful", from, username,
		// password);

		return amt;

	}

	public static long deposit(long amt, long ID)
	{

		Connection dbConnection = dbUtils.getDBConnection();
		int amt1 = 0;
		try
		{
			String sql = "SELECT ACCOUNT_BALANCE FROM ACCOUNT WHERE ACCOUNT_NUMBER=?";
			// pst.setString(1, regdate.getText());
			PreparedStatement pst2 = dbConnection.prepareStatement(sql);
			pst2.setLong(1, ID);
			ResultSet rs = pst2.executeQuery();
			while (rs.next())
			{
				amt1 = rs.getInt(1);
				// System.out.println(amt1);

				long sum = (amt1 + amt);
				String sql3 = "UPDATE ACCOUNT SET ACCOUNT_BALANCE=? WHERE ACCOUNT_NUMBER=?";
				PreparedStatement pst1 = dbConnection.prepareStatement(sql3);
				pst1.setLong(1, sum);
				pst1.setLong(2, ID);
				pst1.executeQuery();

			}

			String insert = "INSERT INTO TRANSACTION VALUES(?,?,?,?,?)";
			PreparedStatement ins1 = dbConnection.prepareStatement(insert);
			ins1.setLong(1, ID);// / get account number on login
			ins1.setTimestamp(2, getCurrentTimeStamp());
			ins1.setString(3, "D");
			ins1.setLong(4, amt);
			ins1.setLong(5, amt1 + amt);

			rs = ins1.executeQuery();

		}

		catch (SQLException e)
		{
			e.printStackTrace();
		}

		return amt;

	}

	public static void CheckBalance(long ID)
	{
		Connection dbConnection = dbUtils.getDBConnection();

		try
		{

			String sql = "SELECT ACCOUNT_BALANCE FROM ACCOUNT WHERE ACCOUNT_NUMBER=?";
			// pst.setString(1, regdate.getText());
			PreparedStatement pst2 = dbConnection.prepareStatement(sql);
			pst2.setLong(1, ID);
			ResultSet rs = pst2.executeQuery();
			while (rs.next())
			{
				long amt1 = rs.getLong(1);
				System.out.println(amt1);

			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	public static boolean checkDay()
	{
		Date today = new Date();
		boolean status = false;
		if ((today.getDay() == 0 || today.getDay() == 6))
		{
			status = true;
		}
		return status;

	}

	public static boolean checkTime()
	{
		Date today = new Date();
		boolean status = false;
		if ((today.getHours() >= 9 && today.getHours() <= 18))
		{
			status = true;
		}
		return status;

	}

	public static boolean checkUser(long recAccNo) throws SQLException
	{
		boolean status = false;
		Connection dbConnection = dbUtils.getDBConnection();

		String s1 = "SELECT IS_ACTIVE FROM ACCOUNT WHERE ACCOUNT_NUMBER=? ";
		PreparedStatement ps = dbConnection.prepareStatement(s1);
		ps.setLong(1, recAccNo);
		ResultSet rs = ps.executeQuery();
		while (rs.next())
		{
			System.out.println(rs.getInt(1));
			if (rs.getInt(1) == 1)
			{
				status = true;
			} else
			{
				status = false;
			}

		}
		return status;
	}

	public static void Transfer() throws SQLException
	{
		System.out
				.println("1.Withdrawl 2.Deposit 3.Transfer Fund 4.Check Balance");
		System.out.println("Enter Choice:");
		// TODO get user_Id from account no
		long ID = 94820;
		int choice = ioUtils.getInteger();

		switch (choice)
		{

		case 1:
			if (!checkDay())
			{
				if (checkTime())
				{
					System.out.println("Enter Amount to Withdraw");
					Long credit = ioUtils.getLong();

					TransferFundView.withdraw(credit, ID);
					System.out.println("Transaction Processed");
				} else
				{
					System.out.println("Deposit only  between 9-18 hrs");
				}
			} else
			{
				System.out
						.println("Transactions are not allowed on saturday and sunday");
			}
			break;
		case 2:
			if (!checkDay())
			{
				if (checkTime())
				{
					System.out.println("Enter Amount to Deposit");
					Long debit = ioUtils.getLong();

					TransferFundView.deposit(debit, ID);
					System.out.println("Transaction Processed");
				} else
				{
					System.out.println("Deposit only in between 9-18 hrs");

				}

			} else
			{
				System.out
						.println("Transactions are not allowed on saturday and sunday");

			}
			break;
		case 3:
			if (!checkDay())
			{
				if (checkTime())
				{

					System.out.println("Enter your account number:");
					long src_acc_no = ioUtils.getLong();

					System.out.println("Enter recepient's account number:");
					long rec_acc_no = ioUtils.getLong();

					boolean userStatus = TransferFundView.checkUser(rec_acc_no);
					if (userStatus)
					{
						System.out.println("Enter the amount to deposit");
						long AMT = ioUtils.getLong();

						TransferFundView.withdraw(AMT, src_acc_no);
						TransferFundView.deposit(AMT, rec_acc_no);
						System.out.println("Transaction Processed");
					}

				} else
				{
					System.out.println("Deposit only in between 9-18 hrs");

				}

			} else
			{
				System.out
						.println("Transactions are not allowed on saturday and sunday");

			}

			break;
		case 4:

			System.out.println("Enter  account number:");
			long acc_no = ioUtils.getLong();
			System.out.println("Balance :");

			TransferFundView.CheckBalance(acc_no);
			break;

		default:
			System.out.println("Invalid Choice");

		}
	}
	/*
	 * method loads register view
	 * 
	 * @return New User
	 */
}
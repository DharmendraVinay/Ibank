package com.sag.bankapp.controller;

//author Dharmendra D -

import java.sql.SQLException;
import java.util.InputMismatchException;

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.exception.DateTimeException;
import com.sag.bankapp.exception.InvalidArgumentException;
import com.sag.bankapp.exception.LogoutException;
import com.sag.bankapp.exception.MainPageException;
import com.sag.bankapp.exception.SessionException;
import com.sag.bankapp.model.UserModel;
import com.sag.bankapp.pojo.User;
import com.sag.bankapp.util.AppProperties;
import com.sag.bankapp.util.DatabaseUtils;
import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.ProfileConnector;
import com.sag.bankapp.util.SessionManager;
import com.sag.bankapp.view.AccountSummaryView;
import com.sag.bankapp.view.HomeView;
import com.sag.bankapp.view.LoginView;
import com.sag.bankapp.view.RegisterNewUserView;

public class Home
{

	private static HomeView homeView;
	private static LoginView loginView;
	private static RegisterNewUserView registerView;
	private static IOUtils ioUtils;
	private static DatabaseUtils dbUtils;

	private static ProfileConnector pfConnector;

	/*
	 * integer determining user choice 1 for login 2 for register 3 for forgot
	 * password
	 */
	private static int response;

	static
	{
		// pfConnector = new ProfileConnector();

		// AppProperties appProperties =
		// ProfileConnector.loadDriverProperties();// load config.properties
		// file
		dbUtils = new DatabaseUtils();

		/*
		 * try { System.out.println("is closed : " +
		 * dbUtils.getDBConnection().isClosed()); } catch (SQLException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); }
		 */

		// appProperties = new AppProperties(); // initiliaze singleton db
		// connection class
		homeView = new HomeView();
		loginView = new LoginView();
		registerView = new RegisterNewUserView();
		ioUtils = new IOUtils();
	}

	public static void main(String[] args)
	{

		boolean isLogoutPressed = false;
		boolean isInputMismatch = false;
		do
		{

			try
			{
				if (SessionManager.isUserLoggedIn)
				{
					// if user is already logged in go to account summary page
					AccountSummaryView accSumView = new AccountSummaryView();

					// user id is "username;number" to load account summary page
					accSumView.loadAccountSummaryView(
							SessionManager.getUserId(),
							SessionManager.getAccountNumber());
				} else
				{

					// else get response
					response = homeView.showHomeMenu();

					switch (response)
					{

					case BankAppConstants.EXISTING_USER:
						loginView.showLoginPage();
						break;

					case BankAppConstants.NEW_USER:
						User newUser = registerView.registerView();
						UserModel userModel = new UserModel();

						// register user and save the account number
						userModel.registerUser(newUser);

						break;

					case BankAppConstants.EXIT_APP:
						isLogoutPressed = true;
						break;

					}
				}

			} catch (InvalidArgumentException e)
			{
				System.err.println("Home - Invalid Argument -> "
						+ e.getMessage());
			} catch (SessionException e)
			{
				SessionManager.destroySession();
				System.err.println("Home - Session/Validation error-> "
						+ e.getMessage());

			} catch (DateTimeException e)
			{
				System.err
						.println("Home - DateTime error -> " + e.getMessage());
			} catch (InputMismatchException e)
			{
				System.err.println("Home - Input Mismatch error ");
				// isInputMismatch = true;
				isLogoutPressed = true;// exit if some unhandled exception comes

			} catch (MainPageException e)
			{
				System.err.println("Home -> navigated to home page");
			} catch (LogoutException e)
			{

				System.err.println("Home - Logout ");
				isLogoutPressed = true;
			} catch (Exception e)
			{
				e.printStackTrace();
				System.err
						.println("Home -> Something went wrong , please try again ");
				isLogoutPressed = true;// exit if some unhandled exception comes
			}

			if (isInputMismatch)
				continue;

			if (isLogoutPressed)
				break;
		} while (true);

		// close i/o stream and db connections
		ioUtils.closeScanner();
		// dbUtils.closeDBConncetion();
		SessionManager.destroySession();
		System.out.println("Exiting... Bye!");

	}

}

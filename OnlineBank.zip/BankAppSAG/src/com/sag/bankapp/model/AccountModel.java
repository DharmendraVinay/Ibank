package com.sag.bankapp.model;


//author Dharmendra D - 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.sag.bankapp.pojo.Account;
import com.sag.bankapp.util.DatabaseUtils;
import com.sag.bankapp.util.DateTimeUtil;
import com.sag.bankapp.util.NetworkUtils;
import com.sag.bankapp.util.SessionManager;

public class AccountModel
{
	private DatabaseUtils dbUtil;
	private Connection dbConnection;
	private int uId;

	public AccountModel()
	{
		dbUtil = new DatabaseUtils();
		dbConnection = dbUtil.getDBConnection();
	}

	public Account getUserAccountFromSet(ResultSet rs) throws SQLException
	{
		Account account = new Account();

		if (rs.next())
		{
			account.setAccountBalnce(rs.getLong("ACCOUNT_BALANCE"));
			account.setAccountNumber(rs.getLong("ACCOUNT_NUMBER"));
			account.setIsActive(rs.getInt("IS_ACTIVE"));
			account.setIsLoggedIn(rs.getInt("IS_LOGGED_IN"));
			account.setIsBelowMinBal(rs.getInt("IS_BELOW_MINIMUM_BALANCE"));
			account.setUserId(rs.getInt("USER_ID"));
			// pass status column not required

		} else
		{
			throw new SQLException("AccountModel  ->  resultset is emty");
		}

		return account;
	}

	// checks if new password was used earlier by user
	public boolean checkAndChangePassword(String confirmPassword, long accNum,
			String email) throws SQLException
	{

		String pwdFetch = "SELECT PASSWORD FROM RECENTPASSWORDS WHERE USER_ID= (SELECT USER_ID FROM ACCOUNT WHERE ACCOUNT_NUMBER=?) ORDER BY DATE_MODIFIED  DESC";
		PreparedStatement accPS = dbConnection.prepareStatement(pwdFetch);
		accPS.setLong(1, accNum);

		ResultSet rs1 = accPS.executeQuery();
		Set<String> userOldPasswordSet = new HashSet<String>();

		int ttlRows = 10;
		while (rs1.next() && ttlRows > 0)
		{
			userOldPasswordSet.add(rs1.getString("password"));
			--ttlRows;
		}

		System.err.println("Last ten password : "
				+ userOldPasswordSet.toString());

		if (userOldPasswordSet.contains(confirmPassword))
		{
			System.err
					.println("Password Already Exists..!! Please create another password..");
			return false;
		} else
		{

			String updPwd = "UPDATE USER_DETAILS SET PASSWORD=? WHERE EMAIL=?";
			PreparedStatement updatePS = dbConnection.prepareStatement(updPwd);
			updatePS.setString(1, confirmPassword);
			updatePS.setString(2, email);
			int rowsInserted = updatePS.executeUpdate();
			if (rowsInserted >= 0)
			{
				System.out.println("Password Updated in DB");

				int rowsInserted1 = insertPasswordEntry(accNum,
						confirmPassword, DateTimeUtil.getCurrentTimeStamp());

				if (rowsInserted1 >= 0)
				{
					System.out
							.println("Passwords Inserted Into Password table successfully");

					String subject = "BankAppSAG | Password Reset";
					String msg = "Congrats you have successfully changed password for account Nummber : "
							+ accNum;
					String from = "dummy404singh@gmail.com";
					String password = "qwer2ASDF";
					String uname = "dummy404singh@gmail.com";
					String to = email;

					NetworkUtils.sendEmail(to, subject, msg, from, uname,
							password);
				} else
				{
					System.out
							.println("Error in inserting into password table");
					return false;
				}

			} else
			{
				System.err.println("Exception while updating password");
			}

			updatePS.close();

		}

		accPS.close();

		return true;

	}

	public int insertPasswordEntry(long accountNumber, String newPassword,
			Timestamp timeStamp) throws SQLException
	{
		String sql="SELECT USER_ID FROM ACCOUNT WHERE ACCOUNT_NUMBER=\'"+accountNumber+"\'";
		Statement st=dbConnection.createStatement();
		ResultSet rs=st.executeQuery(sql);
		while(rs.next())
		{
			uId=rs.getInt("USER_ID");
		}
		String insPwd = "INSERT INTO RECENTPASSWORDS VALUES(?,?,?,PASSWORDS_SEQ.NEXTVAL)";
		PreparedStatement insertPS = dbConnection.prepareStatement(insPwd);
		
		
		insertPS.setInt(1,uId );
		insertPS.setString(2,newPassword);
		insertPS.setTimestamp(3,timeStamp);
	//	insertPS.setInt(4,PreparedStatement.RETURN_GENERATED_KEYS);
		
		int result = insertPS.executeUpdate();
		System.out.println("fo");
		insertPS.close();
		return result;

	}
}

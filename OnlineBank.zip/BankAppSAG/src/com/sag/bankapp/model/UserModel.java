package com.sag.bankapp.model;


//author Dharmendra D - 

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.pojo.Account;
import com.sag.bankapp.pojo.User;
import com.sag.bankapp.util.DatabaseUtils;
import com.sag.bankapp.util.DateTimeUtil;
import com.sag.bankapp.util.NetworkUtils;
import com.sag.bankapp.util.NumberUtility;
import com.sag.bankapp.util.SessionManager;

public class UserModel
{
	private static DatabaseUtils dbUtil;
	private static Connection dbConnect;
	private int uid;

	public UserModel()
	{
		dbUtil = new DatabaseUtils();
		dbConnect = dbUtil.getDBConnection();
	}

	public long registerUser(User user) throws SQLException
	{

		long accountNumber = NumberUtility.generateRandom();
		String query = "INSERT INTO USER_DETAILS VALUES (User_Details_Seq.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try
		{
			// create prepared statememt
			PreparedStatement pstatement = dbConnect.prepareStatement(query);
			//int uid=PreparedStatement.RETURN_GENERATED_KEYS;
//			pstatement.setInt(1, uid);

			pstatement.setString(1, user.getUserName());

			pstatement.setString(2, user.getFirstName());

			pstatement.setString(3, user.getLastName());

			// convert java.util.date to java.sql.date
			pstatement.setDate(4, new Date(user.getDOB().getTime()));

			pstatement.setString(5, user.getEmail());

			pstatement.setLong(6, user.getNumber());

			pstatement.setLong(7, user.getAlternateNumber());

			pstatement.setString(8, user.getHouseNo());

			pstatement.setString(9, user.getPlotNo());

			pstatement.setString(10, user.getStreet());

			pstatement.setString(11, user.getCity());

			pstatement.setString(12, user.getState());

			pstatement.setString(13, user.getSecurityQuestion());

			pstatement.setString(14, user.getSecurityAnswer());

			pstatement.setString(15, user.getPassword());

			pstatement.setInt(16, 0);

			// insert record

			int rowsInserted = pstatement.executeUpdate();
			
			
			pstatement.close();
			if (rowsInserted > 0)
			{
				String sql="SELECT USER_ID FROM USER_DETAILS WHERE EMAIL=\'"+user.getEmail()+"\'";
				Statement st=dbConnect.createStatement();
				ResultSet rs=st.executeQuery(sql);
				
				while(rs.next())
				{
					uid=rs.getInt("USER_ID");
				}
				
				String userId = user.getUserName() + ";" + user.getNumber();
				String msg = " Welcome to SAG BankApp  Your Accont Number Is "
						+ accountNumber + " and  your USER ID is : " + userId;
				String from = "dummy404singh@gmail.com";
				String username = "dummy404singh@gmail.com";
				String password = "qwer2ASDF";
				String subject = "Welcome to SAG BankApp ";

				System.out
						.println("You were Registered as a new user successfully!  ");
				
				
				NetworkUtils.sendEmail(user.getEmail(), subject, msg, from,
						username, password);

				createUserAccount(uid, accountNumber,
						1, 0, 0, 1000);
			}

		}

		catch (SQLException ex)
		{
			ex.printStackTrace();
		}

		AccountModel accModel = new AccountModel();
		accModel.insertPasswordEntry(accountNumber, user.getPassword(),
				DateTimeUtil.getCurrentTimeStamp());
		return accountNumber;
	}

	// creates user account after registering

	public static void createUserAccount(int userid, long accnum, int isactive,
			int isloggedin, int isbelowminbal, float bal)
	{
	
		try
		{

			String sql1 = "INSERT INTO ACCOUNT VALUES(?,?,?,?,?,?,?)";

			PreparedStatement pstatement = dbConnect.prepareStatement(sql1);

			pstatement.setLong(2,accnum);

			pstatement.setInt(1, userid);

			pstatement.setInt(3, 1);

			pstatement.setInt(4, isloggedin);

			pstatement.setInt(5, isbelowminbal);

			pstatement.setDouble(6, 1110.89);

			pstatement.setInt(7, 1);

			pstatement.executeUpdate();

			pstatement.close();
			// System.err.println("UserModel -> Inserted Row " + rowsInserted);

		}

		catch (SQLException e)

		{
			
			e.printStackTrace();

		}
	}

	public ResultSet userAuthenticateQuery(String userName, String password)
			throws SQLException
	{

		Statement stmt = dbConnect.createStatement();
		String query = ("select * from  USER_DETAILS where USER_NAME=? and PASSWORD=?");

		PreparedStatement pstatement = dbConnect.prepareStatement(query);
		pstatement.setString(1, userName);
		pstatement.setString(2, password);

		ResultSet rs = pstatement.executeQuery();
		stmt.close();
		return rs;
	}

	public Account getUserAccount(int userId) throws SQLException
	{
		Statement stmt = dbConnect.createStatement();
		String query = ("select * from  ACCOUNT where USER_ID=? ");

		PreparedStatement pstatement = dbConnect.prepareStatement(query);
		pstatement.setInt(1, userId);

		ResultSet accountRS = pstatement.executeQuery();

		AccountModel accModel = new AccountModel();
		Account account = accModel.getUserAccountFromSet(accountRS);
		stmt.close();
		return account;
	}

	public User getUserFromSet(ResultSet userResultSet) throws SQLException
	{
		User user = new User();
		user.setUserId(userResultSet.getInt("USER_ID"));
		user.setUserName(userResultSet.getString("USER_NAME"));
		user.setFirstName(userResultSet.getString("FIRST_NAME"));
		user.setLastName(userResultSet.getString("LAST_NAME"));
		user.setState(userResultSet.getString("STATE"));
		user.setHouseNo(userResultSet.getString("HOUSE_NUMBER"));
		user.setPlotNo(userResultSet.getString("PLOT_NUMBER"));
		user.setStreet(userResultSet.getString("STREET"));
		user.setCity(userResultSet.getString("CITY"));
		user.setAlternateNumber(userResultSet.getLong("ALTERNATE_CONTACT"));
		user.setEmail(userResultSet.getString("EMAIL"));
		user.setNumber(userResultSet.getLong("PHONE_NUMBER"));
		user.setSecurityQuestion(userResultSet.getString("SECURITY_QUESTION"));
		user.setSecurityAnswer(userResultSet.getString("SECURITY_ANSWER"));
		user.setPassword(userResultSet.getString("PASSWORD"));

		user.setDOB(userResultSet.getDate("DOB"));

		return user;
	}

	public ResultSet getSecurityInfo(String email) throws SQLException
	{
		String sql = "SELECT SECURITY_QUESTION,SECURITY_ANSWER FROM USER_DETAILS WHERE EMAIL=?";
		PreparedStatement st = dbConnect.prepareStatement(sql);
		st.setString(1, email);

		ResultSet rs = st.executeQuery();

		return rs;

	}

	// public void disableUser(String userName)
	// {
	//
	// String sql =
	// "UPDATE ACCOUNT SET IS_ACTIVE = 0 WHERE ,SECURITY_ANSWER FROM USER_REGISTRATION WHERE EMAIL=?";
	// PreparedStatement st = dbConnect.prepareStatement(sql);
	// st.setString(1, email);
	//
	// ResultSet rs = st.executeQuery();
	//
	// return rs;
	// }

}

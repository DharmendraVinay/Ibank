package com.sag.bankapp.model;


//author Dharmendra D - 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import com.sag.bankapp.util.DatabaseUtils;
import com.sag.bankapp.util.SessionManager;

public class AccountSummaryModel
{

	private static DatabaseUtils dbUtil;
	private static Connection dbConnect;
	private Timestamp trans_date;
	private String tot;
	private long amt;

	public AccountSummaryModel()
	{
		dbUtil = new DatabaseUtils();
		dbConnect = dbUtil.getDBConnection();
	}

	public int getUserAccountSummary(int userId)
	{
		try
		{

			Statement stmt = dbConnect.createStatement();
			ResultSet rs;
			rs = stmt
					.executeQuery("select A.ACCOUNT_NUMBER,A.USER_ID,A.ACCOUNT_BALANCE from ACCOUNT A,USER_DETAILS U where U.USER_ID=A.USER_ID AND A.USER_ID=\'"
							+ userId + "\'");
			while (rs.next())
			{
				long ACCOUNT_NUMBER = rs.getLong("ACCOUNT_NUMBER");
				System.out.println("ACCOUNT_NUMBER :" + ACCOUNT_NUMBER);
				int USERID = rs.getInt("USER_ID");
				System.out.println("USER ID :" + USERID);
				Double ACCOUNT_BALANCE = rs.getDouble("ACCOUNT_BALANCE");
				System.out.println("ACCOUNT_BALANCE :" + ACCOUNT_BALANCE);
			}

			stmt.close();

		} catch (SQLException ex)
		{
			ex.printStackTrace();
		}

		return userId;

	}

	public String getTransactionSummary() throws SQLException
	{
		String trans_sql = "SELECT TRANSACTIONS.TRANSACTION_DATE,TRANSACTIONS.TRANSACTION_TYPE,TRANSACTIONS.AMOUNT,ACCOUNT.ACCOUNT_BALANCE FROM TRANSACTIONS ,ACCOUNT  WHERE TRANSACTIONS.ACCOUNT_NUMBER=ACCOUNT.ACCOUNT_NUMBER AND TRANSACTIONS.ACCOUNT_NUMBER=? and TRANSACTIONS.TRANSACTION_DATE > SYSDATE - 30";// AND
		//String trans_sql = "SELECT TRANSACTIONS.TRANSACTION_DATE,TRANSACTIONS.TRANSACTION_TYPE,TRANSACTIONS.AMOUNT FROM TRANSACTIONS WHERE TRANSACTIONS.ACCOUNT_NUMBER=? and TRANSACTIONS.TRANSACTION_DATE > SYSDATE - 30";// AND

		// DATE_AND_TIME
		// between
		// ?
		// AND
		// ?";
		PreparedStatement ps1 = dbConnect.prepareStatement(trans_sql);

		ps1.setLong(1, SessionManager.getAccountNumber());
		/*
		 * ps1.setTimestamp(2, From_day1); ps1.setTimestamp(3, To_day_10);
		 */

		ResultSet rs1 = ps1.executeQuery();

		StringBuffer trnscDetBuffer = new StringBuffer();

		//System.out.println("\tTransaction date \t Transaction Type \t AMOUNT");
		// trnscDetBuffer
		// .append("\tTransaction date \t Transaction Type \t AMOUNT");

		while (rs1.next())
		{
			trans_date = rs1.getTimestamp("TRANSACTION_DATE");
			//System.out.print("\t" + trans_date);
			trnscDetBuffer.append("\t ," + trans_date);
			tot = rs1.getString("TRANSACTION_TYPE");
			//System.out.print("\t " + tot);
			trnscDetBuffer.append("\t , " + tot);
			amt = rs1.getLong("AMOUNT");
			//System.out.print("\t\t " + amt + "\n");
			trnscDetBuffer.append("\t\t , " + amt + "\n");

		}
		
		
		// StringBuffer sb12 = new StringBuffer();
		// bw.append(System.getProperty("line.separator"));
		// sb12.append(trans_date + "                 " + tot +
		// "            "
		// + amt);

		//System.out.println(trnscDetBuffer.toString());
		rs1.close();
		ps1.close();
		return trnscDetBuffer.toString();

	}
}

package com.sag.bankapp.model;


//author Dharmendra D - 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.util.DatabaseUtils;
import com.sag.bankapp.util.DateTimeUtil;
import com.sag.bankapp.util.SessionManager;

public class TransactionModel
{
	private DatabaseUtils dbUtils;
	private Connection dbConnection;
	private long userBalance;

	public TransactionModel() throws SQLException
	{
		dbUtils = new DatabaseUtils();
		dbConnection = dbUtils.getDBConnection();
		dbConnection.setAutoCommit(false);
	}

	// @return newAccountBalance
	public long withdraw(long withdraAmt, long accountNumber)
			throws SQLException
	{
		ResultSet trsRSet;
		boolean isTransactionSuccesfull = false;

		long userBalance = 0;

		String selectQuery = "SELECT ACCOUNT_BALANCE,IS_ACTIVE FROM ACCOUNT WHERE ACCOUNT_NUMBER=?";

		PreparedStatement selectPrdStmt = dbConnection
				.prepareStatement(selectQuery);
		selectPrdStmt.setLong(1, accountNumber);
		trsRSet = selectPrdStmt.executeQuery();
		while (trsRSet.next())
		{
			userBalance = trsRSet.getInt(1);
			int isActive = trsRSet.getInt(2);

			// TODO : set active while login ;
			if (userBalance < 100)
			{
				String updateQuery = "UPDATE ACCOUNT SET IS_BELOW_MINIMUM_BALANCE='1' WHERE ACCOUNT_NUMBER=?";
				PreparedStatement updtPrpdStmt = dbConnection
						.prepareStatement(updateQuery);
				updtPrpdStmt.setLong(1, accountNumber);
				int rowsUpdated = updtPrpdStmt.executeUpdate();

				if (rowsUpdated >= 1)
				{
					System.err
							.println("Minimum balance limit reached , ensure balance above 100");
				} else
				{
					dbConnection.rollback();
					throw new SQLException(
							"TransactionModel -> Something went wrong , please try again");
				}

			}

			else if (withdraAmt > userBalance)
			{
				System.err
						.println("Not sufficient balance found . \n Balance : "
								+ userBalance);

			}

			else
			{

				// withdraw money

				// String =
				// "UPDATE ACCOUNT SET IS_BELOW_MIN_BALANCE='0' WHERE ACCOUNT_NUMBER=?";
				// PreparedStatement pst1 = dbConnection
				// .prepareStatement();
				// pst1.setLong(1, ID);
				// pst1.executeUpdate();

				long balDiff = (userBalance - withdraAmt);
				String updateBalQuery = "UPDATE ACCOUNT SET ACCOUNT_BALANCE=? WHERE ACCOUNT_NUMBER=?";

				PreparedStatement updtBalPrpdStmt = dbConnection
						.prepareStatement(updateBalQuery);
				updtBalPrpdStmt.setLong(1, balDiff);
				updtBalPrpdStmt.setLong(2, accountNumber);

				// transaction succesfull
				if (updtBalPrpdStmt.executeQuery().next())
					isTransactionSuccesfull = true;
				else
				{
					dbConnection.rollback();

					throw new SQLException(
							"TransactionModel -> Failed to update transaction details");
				}

			}
		}

		/*
		 * //CREATE TABLE "TRANSACTION" ( "ACCOUNT_NUMBER" NUMBER(20,0),
		 * "DATE_AND_TIME" TIMESTAMP (6), "TYPE_OF_TRANS" VARCHAR2(40), "AMOUNT"
		 * NUMBER(10,0), "BALANCE" NUMBER(10,0), CONSTRAINT "PK_KEY3333" PRIMARY
		 * KEY ("ACCOUNT_NUMBER", "DATE_AND_TIME") ENABLE, FOREIGN KEY
		 * ("ACCOUNT_NUMBER") REFERENCES "ACCOUNT" ("ACCOUNT_NUMBER") ENABLE ) /
		 */

		// update transactions

		String insertQuery = "INSERT INTO TRANSACTIONS VALUES(?,?,?,?,?,?,?)";
		PreparedStatement insPStmt = dbConnection.prepareStatement(insertQuery);
		insPStmt.setInt(2, PreparedStatement.RETURN_GENERATED_KEYS);// / get
																	// account
																	// number
																	// on
																	// login
		insPStmt.setInt(1, SessionManager.getUserId());
		insPStmt.setLong(3, SessionManager.getAccountNumber());
		insPStmt.setString(4, BankAppConstants.WITHDRAW);
		insPStmt.setLong(5, withdraAmt);
		insPStmt.setString(6, "I AM WITHDRAWING MONEY");
		insPStmt.setTimestamp(7, DateTimeUtil.getCurrentTimeStamp());

		if (isTransactionSuccesfull && !insPStmt.executeQuery().next())
		{

			dbConnection.rollback();

			throw new SQLException(
					"Something went wrong , rolling back withdraw transaction");
		}

		// NetworkUtils.sendEmail("nikeshsraj@gmail.com",
		// "Transaction successful","Transaction successful", from, username,
		// password);
		dbConnection.commit();

		return withdraAmt;

	}

	public void deposit(long amt, long accountNumber)
	{

		try
		{
			// long userBalance = 0;
			boolean isDepositSuccesfull = false;

			String sql = "SELECT ACCOUNT_BALANCE FROM ACCOUNT WHERE ACCOUNT_NUMBER=?";
			// pst.setString(1, regdate.getText());
			PreparedStatement pst2 = dbConnection.prepareStatement(sql);
			pst2.setLong(1, accountNumber);
			ResultSet rs = pst2.executeQuery();

			if (rs.next())
			{
				System.out.println("acc " + rs.getString(1));

				userBalance = rs.getLong("ACCOUNT_BALANCE");
				System.out.println(userBalance);
			}
			long sum = (userBalance + amt);
			System.out.println(sum);
			String sql3 = "UPDATE ACCOUNT SET ACCOUNT_BALANCE=? WHERE USER_ID=?";
			PreparedStatement pst1 = dbConnection.prepareStatement(sql3);
			pst1.setLong(1, sum);
			pst1.setLong(2, SessionManager.getUserId());
			pst1.executeQuery();
			
			/*
			 * if (!pst1.executeQuery().next()) { dbConnection.rollback(); throw
			 * new SQLException(
			 * "Unable to deposit in your account, please try again"); }
			 */
			isDepositSuccesfull = true;

			//
			// String insert = "INSERT INTO TRANSACTION VALUES(?,?,?,?,?,?)";
			// PreparedStatement ins1 = dbConnection.prepareStatement(insert);
			// ins1.setLong(1, accountNumber);// / get account number on login
			// ins1.setTimestamp(2, DateTimeUtil.getCurrentTimeStamp());
			// ins1.setString(3, BankAppConstants.DEPOSIT);
			// ins1.setLong(4, amt);
			String insert = "INSERT INTO TRANSACTIONS VALUES(?,?,?,?,?,?,?)";
			PreparedStatement ins1 = dbConnection.prepareStatement(insert);
			ins1.setInt(2, PreparedStatement.RETURN_GENERATED_KEYS);// / get
																	// account
																	// number
																	// on
																	// login
			ins1.setInt(1, SessionManager.getUserId());
			ins1.setLong(3, SessionManager.getAccountNumber());
			ins1.setString(4, BankAppConstants.DEPOSIT);
			ins1.setLong(5, amt);
			ins1.setString(6, "I AM DEPOSIING MONEY");
			ins1.setTimestamp(7, DateTimeUtil.getCurrentTimeStamp());

			ins1.executeQuery();

			/*
			 * if (!ins1.executeQuery().next()) { dbConnection.rollback(); throw
			 * new SQLException("Error in adding deposit, try again"); }
			 */

			dbConnection.commit();

		} catch (Exception e)
		{
			e.printStackTrace();

		}

	}

	public void checkBalance() throws SQLException
	{

		String sql = "SELECT ACCOUNT_BALANCE FROM ACCOUNT WHERE ACCOUNT_NUMBER=?";
		// pst.setString(1, regdate.getText());
		PreparedStatement pst2 = dbConnection.prepareStatement(sql);
		pst2.setLong(1, SessionManager.getAccountNumber());
		ResultSet rs = pst2.executeQuery();

		if (rs.next())
		{
			long balance = rs.getLong(1);
			System.err.println("Your balance is : " + balance);
		} else
		{
			System.err.println("Account number not found");

		}
	}

	public boolean isUserActive(long accNo) throws SQLException
	{
		boolean status = false;

		String s1 = "SELECT IS_ACTIVE FROM ACCOUNT WHERE ACCOUNT_NUMBER=? ";
		PreparedStatement ps = dbConnection.prepareStatement(s1);
		ps.setLong(1, accNo);
		ResultSet rs = ps.executeQuery();
		while (rs.next())
		{
			System.out.println(rs.getInt(1));
			if (rs.getInt(1) == 1)
			{
				status = true;
			} else
			{
				status = false;
			}

		}
		return status;
	}

}

package com.sag.bankapp.model;


//author Dharmendra D - 

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.exception.InvalidArgumentException;
import com.sag.bankapp.exception.LogoutException;
import com.sag.bankapp.exception.MainPageException;
import com.sag.bankapp.exception.SessionException;
import com.sag.bankapp.services.NetworkResponse;
import com.sag.bankapp.util.DatabaseUtils;
import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.SessionManager;

public class LoginModel
{
	private static DatabaseUtils dbUtil;
	private static Connection dbConnect;
	private UserModel userModel;
	private IOUtils ioUtils;

	public LoginModel()
	{
		dbUtil = new DatabaseUtils();
		dbConnect = dbUtil.getDBConnection();
		ioUtils = new IOUtils();
		userModel = new UserModel();
	}

	public void authenticateUser(String userName, String password,
			NetworkResponse networkResponse) throws SessionException,
			InvalidArgumentException, MainPageException, LogoutException, IOException
	{

		try
		{

			int loginAttempt = 1;
			do
			{
				ResultSet userResultSet = userModel.userAuthenticateQuery(
						userName, password);

				// if user found
				if (userResultSet.next())
				{
					// move cursor back
					// http://stackoverflow.com/questions/867194/java-resultset-how-to-check-if-there-are-any-results
					// userResultSet.beforeFirst();
					// save user in session
					SessionManager.user = userModel
							.getUserFromSet(userResultSet);

					SessionManager.account = userModel
							.getUserAccount(SessionManager.getUserId());

					// successful network response
					networkResponse.networkCallBACK(
							BankAppConstants.SUCCESSFUL_NETWORK_RESPONSE,
							"Login Success");
					return; // return from function

				}

				++loginAttempt;

				if (loginAttempt > BankAppConstants.TOTAL_LOGIN_ATTEMPTS)
					break;

				System.err
						.println("Invalid username or password , please try again \nLogin attempt "
								+ loginAttempt
								+ "/"
								+ BankAppConstants.TOTAL_LOGIN_ATTEMPTS);

				// get username and password again
				System.out.println("Username : ");
				userName = ioUtils.getString();
				if (userName.isEmpty())
					throw new InvalidArgumentException("Username is empty");
				System.out.println("Password : ");
				password = ioUtils.getString();
				if (password.isEmpty())
					throw new InvalidArgumentException("Username is empty");
			} while (true);

			networkResponse.networkCallBACK(
					BankAppConstants.UNSUCCESSFUL_REQUEST,
					"Invalid User name or password");

		} catch (SQLException ex)
		{
			ex.printStackTrace();
		}
	}
}

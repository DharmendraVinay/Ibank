package com.sag.bankapp.view;


//author Dharmendra D - 
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.exception.InvalidArgumentException;
import com.sag.bankapp.exception.LogoutException;
import com.sag.bankapp.exception.MainPageException;
import com.sag.bankapp.exception.SessionException;
import com.sag.bankapp.model.AccountSummaryModel;
import com.sag.bankapp.util.CSVWriter;
import com.sag.bankapp.util.CSVWriterUpdated;
import com.sag.bankapp.util.DatabaseUtils;
import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.NetworkUtils;
import com.sag.bankapp.util.SessionManager;

public class PassbookView
{
	private IOUtils ioUtils;
	private DatabaseUtils dbUtil;
	private Connection dbConnection;

	public PassbookView() throws SQLException
	{
		ioUtils = new IOUtils();
		dbUtil = new DatabaseUtils();
		dbConnection = dbUtil.getDBConnection();

	}

	public void showPassbookView(long accountNumber) throws IOException,
			SQLException, MainPageException, LogoutException,
			InvalidArgumentException, SessionException
	{

		SessionManager.handleSessionExpiration();

		System.out.println("********** Passbook ***********");

		showPassbook(accountNumber);

		System.out.println("Press 1 to Generate Custom Passbook : ");
		System.out.println("8 : For Home ");
		System.out.println("9 : To Logout ");

		int choice = ioUtils.getInteger();

		switch (choice)
		{
		case BankAppConstants.GENERATE_CUSTOM_PASSBOOK:

			CSVWriterUpdated.writeToCSV();

			NetworkUtils netUtil = new NetworkUtils();
			NetworkUtils.sendAttachments("c:\\Custompassbook.csv");

			break;

		case BankAppConstants.HOME_NAVIAGTE:
			throw new MainPageException("Go to main page");

		case BankAppConstants.LOGOUT_CHOICE:
			throw new LogoutException("Logout User");

		default:
			throw new InvalidArgumentException(
					"Invalid choice selected for passbook ");
		}

	}

	private void showPassbook(long accountNumber) throws SQLException
	{

		AccountSummaryModel acMo = new AccountSummaryModel();
		System.out.println(acMo.getTransactionSummary());

	}

	public void showDetails(long accountNumber)
	{

		try
		{

			Statement stmt = dbConnection.createStatement();
			ResultSet rs;
			rs = stmt
					.executeQuery("Select T.ACCOUNT_NUMBER,T.TRANSACTION_DATE,T.TRANSACTION_TYPE,T.AMOUNT,A.BALANCE from TRANSACTIONS T,ACCOUNT A WHERE T.ACCOUNT_NUMBER=\'"
							+ accountNumber
							+ "\'and T.TRANSACTION_DATE >SYSDATE-30 AND A.ACCOUNT_NUMBER=T.ACCOUNT_NUMBER ");

			while (rs.next())
			{
				long ACCOUNT_NUMBER = rs.getLong("ACCOUNT_NUMBER");
				String DATE_AND_TIME = rs.getString("TRANSACTION_DATE");
				String TYPE_OF_TRANS = rs.getString("TRANSACTION_TYPE");
				String AMOUNT = rs.getString("AMOUNT");
				String BALANCE = rs.getString("BALANCE");
				System.out.println("ACCOUNT_NUMBER :::" + ACCOUNT_NUMBER
						+ "  BALANCE :::" + BALANCE + "  DATE_AND_TIME:::"
						+ DATE_AND_TIME + "  TYPE_OF_TRANS :::" + TYPE_OF_TRANS
						+ "  AMOUNT :::" + AMOUNT);
			}

		} catch (Exception ex)
		{
			ex.printStackTrace();
		}

	}
}

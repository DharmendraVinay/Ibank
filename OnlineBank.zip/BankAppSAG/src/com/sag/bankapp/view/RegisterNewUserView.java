package com.sag.bankapp.view;


//author Dharmendra D - 

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;

import com.sag.bankapp.exception.DateTimeException;
import com.sag.bankapp.exception.InvalidArgumentException;
import com.sag.bankapp.model.AccountModel;
import com.sag.bankapp.pojo.User;
import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.StringUtility;

public class RegisterNewUserView
{
	private static IOUtils ioUtils;
	private static StringUtility stringUtils;
	boolean isSpacePresent;

	// SIB for initializing application components
	static
	{
		ioUtils = new IOUtils();
		stringUtils = new StringUtility();
	}

	/*
	 * method loads register view
	 * 
	 * @return New User
	 */
	public User registerView() throws InvalidArgumentException,
			DateTimeException, InputMismatchException
	{
		System.out.println("*********** x New User x ****************");

		User newUser = new User();

		System.out.println("User Name : ");
		newUser.setUserName(ioUtils.getString());

		if (newUser.getUserName().isEmpty())
			throw new InvalidArgumentException("Username is empty");

		System.out.println("First name : ");
		newUser.setFirstName(ioUtils.getString());

		if (newUser.getFirstName().isEmpty())
			throw new InvalidArgumentException("First name is empty");

		// TODO check input

		System.out.println("Last Name : ");
		newUser.setLastName(ioUtils.getString());
		System.out.println("DOB  : dd-MMM-yyyy");

		String date = ioUtils.getString().trim();
		// get date
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Date dob = null;
		System.out.println("date : " + date);

		try
		{
			// Parsing the String
			dob = dateFormat.parse(date);
			newUser.setDOB(dob);
			System.err.println("RegisterNewUserView -> Entered Date : " + date);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
			Date dateLimit = sdf.parse("01-jan-1900");
			if (dob.compareTo(dateLimit) < 0)
				throw new DateTimeException(
						"DOB should be after or equal to 01-jan-1900");

			// https://www.mkyong.com/java/how-to-compare-dates-in-java/

		} catch (ParseException e)
		{

			throw new DateTimeException(e.getMessage());

		}

		System.out.println("Email : ");
		newUser.setEmail(ioUtils.getString());

		if (!stringUtils.isEmailValid(newUser.getEmail()))
			throw new InvalidArgumentException(
					"Invalid email address , please try again");

		System.out.println("Number : ");
		newUser.setNumber(ioUtils.getLong());

		System.out.println("Alternate number : ");
		newUser.setAlternateNumber(ioUtils.getLong());

		ioUtils.getString();

		System.out.println("House no. :");
		newUser.setHouseNo(ioUtils.getString());

		System.out.println("Plot no. :");
		newUser.setPlotNo(ioUtils.getString());

		System.out.println("Street :");
		newUser.setStreet(ioUtils.getString());

		System.out.println("City :");
		newUser.setCity(ioUtils.getString());

		System.out.println("State :");
		newUser.setState(ioUtils.getString());

		System.out.println("Security Question : ");
		newUser.setSecurityQuestion(ioUtils.getString());

		System.out.println("Secuity answer : ");
		newUser.setSecurityAnswer(ioUtils.getString());

		System.out.println("Password :");
		String password, retypedPassword;

		do
		{
			// check if user password contains no white spaces
			do
			{
				password = ioUtils.getString();
				if (stringUtils.containsWhiteSpace(password))
				{
					System.err.println("No spaces allowed , try again ");
					System.out.println("Password : ");
					continue;
				}
				break;
			} while (true);

			boolean doPasswordMatch = false;
			// check if password and retype password matches
			do
			{
				System.out.println("Retype password : ");
				String retypedPaswd = ioUtils.getString();

				if (!stringUtils.validatePassword(password, retypedPaswd))
				{
					System.err
							.println("Password and retype password mismatch, try again \n ");

					continue;
				}
				doPasswordMatch = true;
				break;
			} while (true);

			if (doPasswordMatch)
				break;

		} while (true);

		newUser.setPassword(password);

		return newUser;
	}
}

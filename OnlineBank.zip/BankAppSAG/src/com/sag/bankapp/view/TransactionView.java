package com.sag.bankapp.view;


//author Dharmendra D - 

import java.sql.ResultSet;
import java.sql.SQLException;

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.exception.MainPageException;
import com.sag.bankapp.exception.SessionException;
import com.sag.bankapp.model.TransactionModel;
import com.sag.bankapp.util.DatabaseUtils;
import com.sag.bankapp.util.DateTimeUtil;
import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.NetworkUtils;
import com.sag.bankapp.util.SessionManager;
import com.sag.bankapp.util.StringUtility;

public class TransactionView
{
	// private static long ID;
	private static IOUtils ioUtils;
	private static DatabaseUtils dbUtils;
	private static NetworkUtils networkUtils;
	private static StringUtility stringUtils;
	private boolean isSpacePresent;

	final static String username = "dummy404singh@gmail.com";// change
																// accordingly

	private TransactionModel tranModel;

	public TransactionView() throws SQLException
	{
		ioUtils = new IOUtils();
		dbUtils = new DatabaseUtils();
		stringUtils = new StringUtility();
		tranModel = new TransactionModel();
	}

	public void loadTransactionView() throws SQLException, MainPageException,
			SessionException
	{
		SessionManager.handleSessionExpiration();

		System.out.println("**************  Transactions **************");

		System.out
				.println("1 : Withdrawl \n2 : Deposit \n3 : Transfer Fund \n4 : Check Balance \n8 :  Home page \n9:Logout");
		System.out.println("Enter Choice:");
		// TODO get user_Id from account no
		long accountNumber = SessionManager.getAccountNumber();
		int choice = ioUtils.getInteger();

		switch (choice)
		{

		case BankAppConstants.WITHDRAW_CHOICE:
			if (!DateTimeUtil.isWeekend())
			{
				if (DateTimeUtil.isWorkingHour())
				{
					System.out.println("Enter Amount to Withdraw :");
					long credit = ioUtils.getLong();

					long newBalance = tranModel.withdraw(credit, accountNumber);
					System.out.println("Transaction Processed ");
				} else
				{
					System.err.println("Deposit only  between 9-18 hrs");
				}
			} else
			{
				System.err
						.println("Transactions are not allowed on saturday and sunday");
			}
			break;
		case BankAppConstants.DEPOSIT_CHOICE:
			if (!DateTimeUtil.isWeekend())
			{
				if (DateTimeUtil.isWorkingHour())
				{
					System.out.println("Enter Amount to Deposit : ");
					long debit = ioUtils.getLong();

					tranModel.deposit(debit, accountNumber);
					System.out.println("Transaction Processed");
				} else
				{
					System.err.println("Deposit only in between 9-18 hrs");

				}

			} else
			{
				System.err
						.println("Transactions are not allowed on saturday and sunday");

			}
			break;
		case BankAppConstants.TRANSFER_FUND_OPTION:
			if (!DateTimeUtil.isWeekend())
			{
				if (DateTimeUtil.isWorkingHour())
				{

					System.out.println("Enter recepient's account number:");
					long rec_acc_no = ioUtils.getLong();

					boolean userStatus = tranModel.isUserActive(rec_acc_no);

					// if user found
					if (userStatus)
					{
						System.out.println("Enter the amount to deposit");
						long amount = ioUtils.getLong();

						tranModel.withdraw(amount,
								SessionManager.getAccountNumber());
						tranModel.deposit(amount, rec_acc_no);
						System.out.println("Transaction Processed");
					} else
					{
						System.err.println("Recipient user is not active");
					}

				} else
				{
					System.err.println("Deposit only in between 9-18 hrs");

				}

			} else
			{
				System.err
						.println("Transactions are not allowed on saturday and sunday");

			}

			break;
		case BankAppConstants.CHECK_BALANCE:

			tranModel.checkBalance();
			break;

		case BankAppConstants.HOME_NAVIAGTE:
			throw new MainPageException("Go to main page");

		case BankAppConstants.LOGOUT_CHOICE:
			throw new MainPageException("Logout User");

		default:
			System.err.println("Invalid Choice");

		}
	}

}

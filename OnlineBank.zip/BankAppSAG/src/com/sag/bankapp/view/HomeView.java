package com.sag.bankapp.view;


//author Dharmendra D - 

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.exception.SessionException;
import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.SessionManager;

public class HomeView
{

	private static IOUtils ioUtils;

	// SIB for initializing application components
	static
	{
		ioUtils = new IOUtils();
	}

	/*
	 * prints home page on console for login / register / forgot password menu
	 * 
	 * @return user selected option
	 */
	public int showHomeMenu()
	{

		System.out
				.println("*********** x Welcome to SAG BankApp x ***********");

		System.out.println("\nChoose your option.....\n"
				+ BankAppConstants.NEW_USER + ". New User\n"
				+ BankAppConstants.EXISTING_USER + ". Existing\n"
				+ BankAppConstants.EXIT_APP + " : Exit");

		int userChoise = ioUtils.getInteger();
		System.err.println("HomeView -> user selected : " + userChoise);
		return userChoise;
	}

}

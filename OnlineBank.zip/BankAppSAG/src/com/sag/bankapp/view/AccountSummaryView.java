package com.sag.bankapp.view;


//author Dharmendra D - 
import java.io.IOException;
import java.sql.SQLException;

import javax.security.auth.login.LoginException;

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.exception.InvalidArgumentException;
import com.sag.bankapp.exception.LogoutException;
import com.sag.bankapp.exception.MainPageException;
import com.sag.bankapp.exception.SessionException;
import com.sag.bankapp.model.AccountSummaryModel;
import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.SessionManager;

public class AccountSummaryView
{
	IOUtils ioUtils;

	// Successfully signed in user
	// A page representing set of features: Account Summary, Make fund transfer,
	// View Passbook,
	// Change password should be displayed.

	AccountSummaryModel accountSumModel;

	public AccountSummaryView()
	{
		accountSumModel = new AccountSummaryModel();
		ioUtils = new IOUtils();
	}

	public void loadAccountSummaryView(int userId, long accountNumber)
			throws SessionException, SQLException, MainPageException, IOException, LogoutException, InvalidArgumentException

	{
		SessionManager.handleSessionExpiration();

		System.out
				.println("=============== x  ACCOUNT SUMMARY x  ====================");

		accountSumModel.getUserAccountSummary(userId);

		System.out.println();
		System.out.println("1 : To Make fund transfer ");
		System.out.println("2 : To View Passbook ");
		System.out.println("3 : To Change Password");
		System.out.println("9 : To Logout ");

		int userChoice = -1;

		userChoice = ioUtils.getInteger();

		switch (userChoice)
		{
		case BankAppConstants.TRANSFER_FUND:
			TransactionView trnscView = new TransactionView();
			trnscView.loadTransactionView();

			break;
		case BankAppConstants.VIEW_PASSBOOK:

			PassbookView pbView = new PassbookView();
			System.err
					.println("Account Summary -> user_account_for_passbook  -> "
							+ accountNumber);
			pbView.showPassbookView(accountNumber);

			break;
		case BankAppConstants.CHANGE_PASSWORD:
			ChangePasswordView cpView = new ChangePasswordView();
			cpView.loadChangePasswordView();
			break;

		case BankAppConstants.HOME_NAVIAGTE:
			throw new MainPageException("Go to main page");

		case BankAppConstants.LOGOUT_CHOICE:
			throw new LogoutException("Logout User");

		default:
			throw new InvalidArgumentException("Invalid Input selected");

		}

	}
}

package com.sag.bankapp.view;


//author Dharmendra D - 

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.exception.InvalidArgumentException;
import com.sag.bankapp.exception.SessionException;
import com.sag.bankapp.model.AccountModel;
import com.sag.bankapp.model.UserModel;
import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.NetworkUtils;
import com.sag.bankapp.util.SessionManager;
import com.sag.bankapp.util.StringUtility;

public class ForgotPasswordView
{

	private IOUtils ioUtils;

	public ForgotPasswordView()
	{
		ioUtils = new IOUtils();
	}

	public void showFGPView() throws SQLException, InvalidArgumentException,
			SessionException
	{

		System.out.println("************ Forgot Password ******************");

		System.out.println("Your account nummber : ");
		long accountNumber = ioUtils.getLong();
		ioUtils.getString(); // get input from next line
		System.out.println("Your email address : ");
		String email = ioUtils.getString();

		System.err.println("Email -> " + email + " acc num : " + accountNumber);

		AccountModel accModel = new AccountModel();
		UserModel usrModel = new UserModel();

		StringUtility sUtil = new StringUtility();
		if (!sUtil.isEmailValid(email))
			throw new InvalidArgumentException("Invalid emaill address");

		ResultSet userSet = usrModel.getSecurityInfo(email);

		if (userSet.next())
		{

			String question;
			System.out.println("Your Security Question is:");
			question = userSet.getString("SECURITY_QUESTION");
			System.out.println(question);
			System.out.println("Please enter the security answer:");
			String answer = ioUtils.getString();
			String resultsetAnswer = userSet.getString("SECURITY_ANSWER");
			if (answer.equalsIgnoreCase(resultsetAnswer))
			{
				Random mathRandom = new Random();
				boolean verify = false;
				long verifyOTP = 0;
				System.out
						.println("Please check your registered mail id for the Temporary password");
				long OTP = 10000 + (long) mathRandom.nextInt(89999);

				NetworkUtils.sendEmail(email, "BankApp temporary password",
						"Your temporary password is : " + OTP,
						BankAppConstants.BANK_EMAIL,
						BankAppConstants.BANK_EMAIL,
						BankAppConstants.BANK_EMAIL_PASSWORD);

				// MAIL THIS OTP TO USER MAIL ID
				// System.out.println("OTP IS : " + OTP);

				// while otp not verified
				while (!verify)
				{

					System.out
							.println("Enter the new temporary password recieved");
					verifyOTP = ioUtils.getLong();
					ioUtils.getString();

					if (OTP == verifyOTP)
					{
						verify = true;
						System.out.println("OTP Verified");
						ChangePasswordView chpPassView = new ChangePasswordView();
						chpPassView.createPassword(accountNumber, email);
					}

					else
					{
						System.err
								.println("OTP is Incorrect...Please re-enter the OTP!!");
					}
				}

			} else
			{
				System.err.println("Answer entered is Wrong");
				showFGPView();
			}

		} else
		{
			System.err
					.println("Forgot Password -> Please enter your registered Email address..");
			showFGPView();

		}
		userSet.close();
	}
}

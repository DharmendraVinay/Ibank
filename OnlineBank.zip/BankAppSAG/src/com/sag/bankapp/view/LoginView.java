package com.sag.bankapp.view;


//author Dharmendra D - 

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.exception.InvalidArgumentException;
import com.sag.bankapp.exception.LogoutException;
import com.sag.bankapp.exception.MainPageException;
import com.sag.bankapp.exception.SessionException;
import com.sag.bankapp.model.LoginModel;
import com.sag.bankapp.model.UserModel;
import com.sag.bankapp.pojo.User;
import com.sag.bankapp.services.NetworkResponse;
import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.SessionManager;

public class LoginView
{

	private IOUtils ioUtils;
	private LoginModel loginModel;

	public LoginView()
	{
		ioUtils = new IOUtils();
		loginModel = new LoginModel();
	}

	public void showLoginPage() throws InvalidArgumentException,
			SessionException, SQLException, MainPageException, LogoutException, IOException
	{
		System.out.println("*********** x Login x ****************");

		System.out.println("Enter user name :");

		System.out.println("Forgot password ? Press 1...");

		String response = ioUtils.getString();
		if (response.equals("1"))
		{
			// TODO handle case when user's password is 1

			ForgotPasswordView fgPView = new ForgotPasswordView();
			fgPView.showFGPView();

		} else
		{

			String userName = response;

			System.out.println("username : " + userName);
			if (userName.isEmpty())
				throw new InvalidArgumentException(
						"Username is empty , please try again");

			System.out.println(" Enter password:");

			String password = ioUtils.getString();

			if (password.isEmpty())
				throw new InvalidArgumentException(
						"Password is empty , please try again");

			// pass anonymous network callback interface object to listen
			// network
			// callbacks as network calls may be in different threads in next
			// updates

			loginModel.authenticateUser(userName, password,
					new NetworkResponse()
					{

						@Override
						public void networkCallBACK(int status, String statusMsg)
								throws SessionException,
								InvalidArgumentException, SQLException,
								MainPageException, LogoutException, IOException
						{
							if (status == BankAppConstants.SUCCESSFUL_NETWORK_RESPONSE)
							{

								// start active time stamp
								SessionManager.lastActiveTimeStamp = new Date();

								System.err.println("LoginView -> " + statusMsg);
								SessionManager.startSession();
								AccountSummaryView accSumView = new AccountSummaryView();

								// System.out.println(SessionManager.getAccountNumber());
								// user is id username;number to laod account
								// summary page
								accSumView.loadAccountSummaryView(
										SessionManager.getUserId(),
										SessionManager.getAccountNumber());

							} else
							{

								UserModel usrModel = new UserModel();
								// usrModel.disableUser(userName);
								throw new SessionException(statusMsg);
							}
						}
					});

		}
	}
}

package com.sag.bankapp.view;

//author Dharmendra D - 

import java.sql.Connection;
import java.sql.SQLException;

import javax.xml.bind.DataBindingException;

import com.sag.bankapp.exception.SessionException;
import com.sag.bankapp.model.AccountModel;
import com.sag.bankapp.util.DatabaseUtils;
import com.sag.bankapp.util.IOUtils;
import com.sag.bankapp.util.SessionManager;
import com.sag.bankapp.util.StringUtility;

public class ChangePasswordView
{
	private IOUtils ioUtils;

	private StringUtility stringUtil;

	public ChangePasswordView()
	{
		ioUtils = new IOUtils();

		stringUtil = new StringUtility();

	}

	public void loadChangePasswordView() throws SQLException, SessionException
	{
		System.out.println("*********** Change Password ***********");

		SessionManager.handleSessionExpiration();

		this.createPassword(SessionManager.getAccountNumber(),
				SessionManager.getEmail()); // only called when logged in

	}

	public void createPassword(long accNum, String email) throws SQLException,
			SessionException
	{

		String newPassword = null;
		String confirmPassword = null;
		boolean status;
		System.out.println("Enter password : ");
		newPassword = ioUtils.getString();
		do
		{
			if (!stringUtil.containsWhiteSpace(newPassword))
			{
				break;
			}
			System.err
					.println("Password Contains Spaces. Please re-enter the password");

		} while (true);

		System.out.println("Confirm the password");
		confirmPassword = ioUtils.getString();

		if (stringUtil.validatePassword(newPassword, confirmPassword))
		{
			AccountModel accModel = new AccountModel();

			if (accModel.checkAndChangePassword(confirmPassword, accNum, email))
			{

			} else
			{
				createPassword(accNum, email);// password exist in db

			}
		} else
		{
			System.err.println("Passwords not Matched");
			// createpassword();
			loadChangePasswordView();
		}

	}

}

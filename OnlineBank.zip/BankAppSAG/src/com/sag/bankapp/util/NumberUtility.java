package com.sag.bankapp.util;

import java.util.Random;

public class NumberUtility
{

	public static long generateRandom()
	{
		Random random = new Random();
		StringBuilder sb = new StringBuilder();

		// first not 0 digit
		sb.append(random.nextInt(6) + 1);

		// rest of 11 digits
		for (int i = 0; i < 11; i++)
		{
			sb.append(random.nextInt(6));
		}

		return Long.valueOf(sb.toString()).longValue();
	}

	public static long generateOTP()
	{
		long OTP = 0;
		Random r = new Random();
		OTP = 10000 + (long) r.nextInt(89999);// MAIL THIS OTP TO USER MAIL ID
		System.err.println("NumberUtility-> OTP IS:" + OTP);
		return OTP;
	}

}

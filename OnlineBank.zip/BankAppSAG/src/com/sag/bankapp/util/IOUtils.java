package com.sag.bankapp.util;

import java.util.Scanner;

public class IOUtils
{

	private Scanner in;

	public IOUtils()
	{
		in = new Scanner(System.in);
	}

	public final void clearConsole()
	{
		try
		{
			final String os = System.getProperty("os.name");
			if (os.contains("Windows"))
			{
				Runtime.getRuntime().exec("cls");
			} else
			{
				Runtime.getRuntime().exec("clear");
			}
		} catch (final Exception e)
		{

		}
	}

	/*
	 * returns input integer from user
	 */
	public int getInteger()
	{
		return in.nextInt();
	}

	// closes io scanner stream
	public void closeScanner()
	{
		this.in.close();
	}

	public String getString()
	{
		return in.nextLine().trim();
	}

	public long getLong()
	{
		return in.nextLong();
	}



	

}

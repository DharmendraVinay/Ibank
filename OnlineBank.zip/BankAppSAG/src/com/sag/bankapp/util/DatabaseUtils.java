package com.sag.bankapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtils
{

	// TODO make it a singleton class
	
	private static Connection dbConnection;

	public static void validateConnection()
	{

		getDBConnection();

	}

	public static Connection getDBConnection()
	{
		AppProperties appProperties  = ProfileConnector.loadDriverProperties();
		
		try
		{

			Class.forName(appProperties.getDriver());

		} catch (ClassNotFoundException e)
		{

			System.out.println(e.getMessage());

		}

		try
		{

			dbConnection = DriverManager.getConnection(appProperties.getConnection(), appProperties.getDbuser(),
					appProperties.getDbpassword());

			return dbConnection;

		} catch (SQLException e)
		{

			System.out.println(e.getMessage());

		}

		return dbConnection;

	}

	public void closeDBConncetion()
	{
		try
		{
			dbConnection.close();
		} catch (SQLException e)
		{
			System.err.println("DatabaseUtils -> Error closing db connection");
		}
	}

}

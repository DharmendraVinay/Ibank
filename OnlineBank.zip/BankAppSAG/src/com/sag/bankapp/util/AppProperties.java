package com.sag.bankapp.util;

public class AppProperties
{
	private String driver;
	private String connection;
	private String dbuser;
	private String dbpassword;
	private static AppProperties appProper = new AppProperties()  ;



	public String getDriver()
	{
		return driver;
	}

	public void setDriver(String driver)
	{
		this.driver = driver;
	}

	public String getConnection()
	{
		return connection;
	}

	public void setConnection(String connection)
	{
		this.connection = connection;
	}

	public String getDbuser()
	{
		return dbuser;
	}

	public void setDbuser(String dbuser)
	{
		this.dbuser = dbuser;
	}

	public String getDbpassword()
	{
		return dbpassword;
	}

	public void setDbpassword(String dbpassword)
	{
		this.dbpassword = dbpassword;
	}

	public static AppProperties getInstance()
	{
		return appProper;
	}

}

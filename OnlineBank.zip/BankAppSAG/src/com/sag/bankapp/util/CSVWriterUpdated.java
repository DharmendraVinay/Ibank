package com.sag.bankapp.util;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.sag.bankapp.model.AccountSummaryModel;

public class CSVWriterUpdated
{
	private static final String COMMA_DELIMITER = ",";

	private static final String NEW_LINE_SEPARATOR = "\n";

	private static final String FILE_HEADER = "TRANSACTION_DATE,TRANSACTION_TYPE,AMOUNT";

	private String date_and_time;
	private String tot;
	private long amt;

	private static String uName;

	private static String hNo;

	private static String pNo;

	private static String street;

	private static String city;

	private static String state;

	private static String phNo;

	private static long accNumber;

	private static String anum;

	public static void writeToCSV() throws IOException, SQLException
	{

		FileWriter fw;
		String filename = "c:\\Custompassbook.csv";
		fw = new FileWriter(filename);

		DatabaseUtils dbUtil = new DatabaseUtils();
		Connection dbConnect = dbUtil.getDBConnection();
		dbConnect = dbUtil.getDBConnection();

		String sql = "SELECT U.USER_NAME,U.HOUSE_NUMBER,U.PLOT_NUMBER,U.STREET,U.CITY,U.STATE,U.PHONE_NUMBER,A.ACCOUNT_NUMBER FROM USER_DETAILS U,ACCOUNT A WHERE U.USER_ID=? AND U.USER_ID=A.USER_ID";
		PreparedStatement ps = dbConnect.prepareStatement(sql);
		ps.setInt(1, SessionManager.getUserId());

		ResultSet rs = ps.executeQuery();
		while (rs.next())
		{
			uName = rs.getString("USER_NAME");
			hNo = rs.getString("HOUSE_NUMBER");
			pNo = rs.getString("PLOT_NUMBER");
			street = rs.getString("STREET");
			city = rs.getString("CITY");
			state = rs.getString("STATE");
			phNo = rs.getString("PHONE_NUMBER");
			accNumber = rs.getLong("ACCOUNT_NUMBER");
			anum = rs.getString("ACCOUNT_NUMBER").toString();
		}
		fw.append("PASSBOOK");
		fw.append(System.getProperty("line.separator"));

		fw.append("NAME" + "                   " + SessionManager.getUsername());
		fw.append(System.getProperty("line.separator"));
		fw.append("ADDRESS" + "                   "
				+ SessionManager.getHouseNo() + COMMA_DELIMITER
				+ SessionManager.getPlotNo() + COMMA_DELIMITER
				+ SessionManager.getStreet() + COMMA_DELIMITER
				+ SessionManager.getCity() + COMMA_DELIMITER
				+ SessionManager.getState());
		fw.append(System.getProperty("line.separator"));
		fw.append("PHONE NUMBER" + "                   "
				+ SessionManager.getNumber());
		fw.append(System.getProperty("line.separator"));
		fw.append("ACCOUNT NUMBER" + "                   "
				+ SessionManager.getAccountNumber());
		fw.append(System.getProperty("line.separator"));
		fw.append("TRANSACTIONS_SUMMARY");
		fw.append(System.getProperty("line.separator"));

		Scanner sc = new Scanner(System.in);
		String start_date;
		String end_date;

		System.out
				.println("Please enter the Duration of Transaction that you would like to print");

		System.out.println("Enter the start date:  IN THE format dd/MMM/yyyy ");// 07/SEP/2016
		start_date = sc.next();

		System.out.print("Enter the end date:  IN THE format dd/MMM/yyyy ");
		end_date = sc.next();
		String query = "SELECT TRANSACTIONS.TRANSACTION_DATE,TRANSACTIONS.TRANSACTION_TYPE,TRANSACTIONS.AMOUNT"
				+ "  FROM TRANSACTIONS WHERE TRANSACTIONS.ACCOUNT_NUMBER='"
				+ accNumber
				+ "' AND TRANSACTIONS.TRANSACTION_DATE>'"
				+ start_date
				+ "'AND TRANSACTIONS.TRANSACTION_DATE<'"
				+ end_date + "'";
		Statement st = dbConnect.createStatement();
		ResultSet rs1 = st.executeQuery(query);
		ResultSetMetaData rsmd = rs1.getMetaData();

		int columnCount = rsmd.getColumnCount();
		for (int i = 1; i <= columnCount; i++)
		{
			fw.append(rsmd.getColumnName(i));
			fw.append(",");
		}
		fw.append(System.getProperty("line.separator"));
		while (rs1.next())
		{
			for (int i = 1; i <= columnCount; i++)
			{

				// you can update it here by using the column type but i am
				// fine with the data so just converting
				// everything to string first and then saving
				/*
				 * if (rs1.getObject(i) != null) { String data =
				 * rs1.getObject(i).toString(); fw.append(data); fw.append(",");
				 * } else { String data = "null"; fw.append(data);
				 * fw.append(","); }
				 */
			}

			fw.append(new AccountSummaryModel().getTransactionSummary());
			// new line entered after each row
			fw.append(System.getProperty("line.separator"));
			// System.out.println("Write to CSV file successful");
			 fw.append("ACCOUNT BALANCE");
			 fw.append(String.valueOf(SessionManager.getAccountBalance()));
			 fw.append(System.getProperty("line.separator"));
			
		}

		// fw.append("ACCOUNT BALANCE");
		// fw.append(String.valueOf(SessionManager.getAccountBalance()));
		// fw.append(System.getProperty("line.separator"));
		System.out.println("Write to CSV file successful");
		fw.flush();
		fw.close();
		// }
	}

}

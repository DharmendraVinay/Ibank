package com.sag.bankapp.util;

import java.util.Date;

public class DateTimeUtil
{

	public static java.sql.Timestamp getCurrentTimeStamp()
	{

		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());

	}

	public static boolean isWeekend()
	{
		Date today = new Date();
		boolean status = false;
		if ((today.getDay() == 0 || today.getDay() == 6))
		{
			status = true;
		}
		return status;

	}

	// public static boolean isWeekend()
	// {
	//
	// if ((Calendar.DAY_OF_WEEK == Calendar.SUNDAY || Calendar.DAY_OF_WEEK ==
	// Calendar.SATURDAY))
	// {
	// return true;
	// }
	// return false;
	//
	// }


	public static boolean isWorkingHour()
	{
		Date today = new Date();
		boolean status = false;
		if ((today.getHours() >= 9 && today.getHours() <= 18))
		{
			status = true;
		}
		return status;

	}

}

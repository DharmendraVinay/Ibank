package com.sag.bankapp.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.beans.Statement;
import java.io.*;

import javax.mail.Session;

import com.sag.bankapp.model.AccountSummaryModel;
import com.sag.bankapp.pojo.PassBook;

public class CSVWriter
{
	public static String start_Date;
	public static String end_Date;
	private static Timestamp trans_date;

	private static final String COMMA_DELIMITER = ",";

	private static final String NEW_LINE_SEPARATOR = "\n";

	private static final String FILE_HEADER = "dateTime,type of transaction,amount,currentBalance";

	private static DatabaseUtils dbUtil;

	private static Connection dbConnect;
	private static String tot;
	private static long amt;
	private static long bal;

	// public static void writeTOCSV() throws SQLException, IOException
	// {
	//
	// createCustomPassbook();
	// return;
	// /*
	// * String sql =
	// *
	// "SELECT U.USER_NAME,U.HOUSE_NO,U.PLOT_NO,U.STREET,U.CITY,U.STATE,U.CONTACT_NO,A.ACCOUNT_NUMBER FROM USER_REGISTRATION U,ACCOUNT A WHERE U.USER_ID=?"
	// * ;
	// *
	// * PreparedStatement ps = dbConnect.prepareStatement(sql);
	// *
	// * ps.setInt(1, 1);
	// *
	// * ResultSet rs = ps.executeQuery();
	// *
	// * while (rs.next())
	// *
	// * {
	// *
	// * // uName = rs.getString("USER_NAME"); // //
	// * System.out.println(uName); // // hNo = rs.getString("HOUSE_NO"); //
	// * // System.out.println(hNo); // // plNo = rs.getString("PLOT_NO"); //
	// * // System.out.println(plNo); // // street = rs.getString("STREET");
	// * // // System.out.println(street); // // city = rs.getString("CITY");
	// * // // System.out.println(city); // // state = rs.getString("STATE");
	// * // // System.out.println(state); // // cNo =
	// * rs.getLong("CONTACT_NO"); // // System.out.println(cNo); // // aNo =
	// * rs.getLong("ACCOUNT_NUMBER"); // // System.out.println(aNo);
	// *
	// * } // Create new PassBook objects PassBook pb1 = new
	// * PassBook("02-sep-16;11:32", "Debit", 500, 500); PassBook pb2 = new
	// * PassBook("02-sep-16;11:35", "Debit", 500, 1000); PassBook pb3 = new
	// * PassBook("02-sep-16;11:38", "Debit", 500, 1500); PassBook pb4 = new
	// * PassBook("02-sep-16;11:44", "Debit", 500, 2000); PassBook pb5 = new
	// * PassBook("02-sep-16;11:50", "Debit", 500, 2500); // Create a new list
	// * of student objects ArrayList<PassBook> passBookEntry = new
	// * ArrayList<PassBook>(); passBookEntry.add(pb1);
	// * passBookEntry.add(pb2); passBookEntry.add(pb3);
	// * passBookEntry.add(pb4); passBookEntry.add(pb5);
	// *
	// * FileWriter fileWriter = null;
	// *
	// * try { fileWriter = new FileWriter(path);
	// *
	// * // Write the CSV file header
	// * fileWriter.append(FILE_HEADER.toString());
	// *
	// * // Add a new line separator after the header
	// * fileWriter.append(NEW_LINE_SEPARATOR);
	// *
	// * // Write a new PassBook object list to the CSV file for (PassBook pb
	// * : passBookEntry) { fileWriter.append(pb.getDateTime());
	// * fileWriter.append(COMMA_DELIMITER); fileWriter.append(pb.getTOT());
	// * fileWriter.append(COMMA_DELIMITER);
	// * fileWriter.append(String.valueOf(pb.getAmount()));
	// * fileWriter.append(COMMA_DELIMITER);
	// * fileWriter.append(String.valueOf(pb.getCurrentBalance()));
	// * fileWriter.append(NEW_LINE_SEPARATOR); }
	// *
	// * System.out.println("CSV file was created successfully !!!");
	// *
	// * } catch (Exception e) {
	// * System.out.println("Error in CsvFileWriter !!!");
	// * e.printStackTrace(); } finally {
	// *
	// * try { fileWriter.flush(); fileWriter.close(); } catch (IOException e)
	// * { System.out .println("Error while flushing/closing fileWriter !!!");
	// * e.printStackTrace(); }
	// *
	// * }
	// */
	// }
	//
	// // private static void createCustomPassbook() throws IOException,
	// SQLException
	// {
	//
	// dbUtil = new DatabaseUtils();
	// dbConnect = dbUtil.getDBConnection();
	// dbConnect = dbUtil.getDBConnection();
	//
	// /* FileWriter fw = new FileWriter("c:\\Custompassbook.csv"); */
	// FileWriter fw;
	// String filename = "c:\\Custompassbook.csv";
	// fw = new FileWriter(filename);
	//
	// BufferedWriter bw = new BufferedWriter(fw);
	//
	// StringBuffer sb1 = new StringBuffer();
	// sb1.append("_________________________________________________________________________");
	// sb1.append('\n');
	// sb1.append(" _________________________________PASSBOOK________________________________");
	// sb1.append('\n');
	//
	// bw.append(sb1);
	//
	// bw.append(System.getProperty("line.separator"));
	//
	// StringBuffer sb2 = new StringBuffer();
	//
	// sb2.append("NAME                 :");
	//
	// bw.append(sb2);
	//
	// bw.append(SessionManager.getUsername());
	//
	// bw.append(System.getProperty("line.separator"));
	// StringBuffer sb3 = new StringBuffer();
	// sb3.append("ADDRESS              :");
	// sb3.append(SessionManager.getHouseNo());
	// sb3.append(SessionManager.getPlotNo());
	// sb3.append(SessionManager.getStreet());
	// sb3.append(SessionManager.getCity());
	// sb3.append(SessionManager.getState());
	// bw.append(sb3);
	// bw.append(System.getProperty("line.separator"));
	// StringBuffer sb4 = new StringBuffer();
	// sb4.append("ACOUNT NUMBER        :");
	// sb4.append(SessionManager.getAccountNumber());
	// bw.append(sb4);
	// bw.append(System.getProperty("line.separator"));
	// StringBuffer sb5 = new StringBuffer();
	// sb5.append("CONTACT NUMBER       :");
	// sb5.append(SessionManager.getNumber());
	// bw.append(sb5);
	//
	// bw.append(System.getProperty("line.separator"));
	// StringBuffer sb6 = new StringBuffer();
	// sb6.append('\n');
	// sb6.append('\n');
	// sb6.append('\n');
	// sb6.append("TRANSACTIONS SUMMARY");
	// bw.append(sb6);
	// StringBuffer sb9 = new StringBuffer();
	//
	// bw.append(sb9);
	// bw.append(System.getProperty("line.separator"));
	//
	// StringBuffer sb7 = new StringBuffer();
	// sb7.append("DATE_AND_TIME" + "               " + "TYPE OF TRANSACTION"
	// + "           " + "AMOUNT");
	// bw.append(System.getProperty("line.separator"));
	// bw.append(sb7);
	// StringBuffer sb10 = new StringBuffer();
	// sb10.append("_________________________________________________________________________");
	// bw.append(System.getProperty("line.separator"));
	//
	// bw.append(sb10);
	// bw.append(System.getProperty("line.separator"));
	//
	// Scanner sc = new Scanner(System.in);
	//
	// System.out.println('\n');
	//
	// System.out
	// .println("Please enter the Duration of Transaction that you would like to print");
	//
	// System.out.println("Enter the start date:  IN THE format dd/MMM/yyyy ");//
	// 07/SEP/2016
	// String start_date = sc.next();
	//
	// System.out.print("Enter the end date:  IN THE format dd/MMM/yyyy ");
	// String end_date = sc.next();
	// String query =
	// "SELECT TRANSACTIONS.TRANSACTION_TYPE,TRANSACTIONS.AMOUNT,TRANSACTIONS.TRANSACTION_DATE"
	// + "  FROM TRANSACTIONS WHERE TRANSACTIONS.ACCOUNT_NUMBER='"
	// + SessionManager.getAccountNumber()
	// + "' AND TRANSACTIONS.TRANSACTION_DATE>'"
	// + start_date
	// + "'AND TRANSACTIONS.TRANSACTION_DATE<'" + end_date + "'";
	// java.sql.Statement st = dbConnect.createStatement();
	// ResultSet rs1 = st.executeQuery(query);
	// ResultSetMetaData rsmd = rs1.getMetaData();
	//
	// int columnCount = rsmd.getColumnCount();
	// for (int i = 1; i <= columnCount; i++)
	// {
	// fw.append(rsmd.getColumnName(i));
	// fw.append(",");
	// }
	// fw.append(System.getProperty("line.separator"));
	// while (rs1.next())
	// {
	// for (int i = 1; i <= columnCount; i++)
	// {
	//
	// // you can update it here by using the column type but i am
	// // fine with the data so just converting
	// // everything to string first and then saving
	// if (rs1.getObject(i) != null)
	// {
	// String data = rs1.getObject(i).toString();
	// fw.append(data);
	// fw.append(",");
	// } else
	// {
	// String data = "null";
	// fw.append(data);
	// fw.append(",");
	// }
	//
	// }
	//
	// //
	// System.out.print("Enter the start date:  IN THE format dd/MMM/yyyy ");//
	// // 07/SEP/2016
	// // start_Date = sc.next();
	// // System.out.println(start_Date);
	// // Timestamp From_day1 = convertStringToTimestamp(start_Date);
	// //
	// // System.out.print("Enter the end date:  IN THE format dd/MMM/yyyy ");
	// // end_Date = sc.next();
	// // Timestamp To_day_10 = convertStringToTimestamp(end_Date);
	//
	// // System.out.println(From_day1 + " " + To_day_10);
	//
	// // String trans_sql =
	// //
	// "SELECT DATE_AND_TIME,TYPE_OF_TRANS,AMOUNT,BALANCE FROM TRANSACTION WHERE ACCOUNT_NUMBER=? and DATE_AND_TIME > SYSDATE - 30";//
	// // AND
	// // // DATE_AND_TIME
	// // // between
	// // // ?
	// // // AND
	// // // ?";
	// // PreparedStatement ps1 = dbConnect.prepareStatement(trans_sql);
	// //
	// // ps1.setLong(1, SessionManager.getAccountNumber());
	// // /*
	// // * ps1.setTimestamp(2, From_day1); ps1.setTimestamp(3, To_day_10);
	// // */
	// //
	// // ResultSet rs1 = ps1.executeQuery();
	// //
	// // StringBuffer trnscDetBuffer = new StringBuffer();
	// //
	// //
	// System.out.println("\tTransaction date \t Transaction Type \t AMOUNT");
	// // // trnscDetBuffer
	// // // .append("\tTransaction date \t Transaction Type \t AMOUNT");
	// //
	// // while (rs1.next())
	// // {
	// // trans_date = rs1.getTimestamp("DATE_AND_TIME");
	// // //System.out.print("\t" + trans_date);
	// // trnscDetBuffer.append("\t ," + trans_date);
	// // tot = rs1.getString("TYPE_OF_TRANS");
	// // //System.out.print("\t " + tot);
	// // trnscDetBuffer.append("\t , " + tot);
	// // amt = rs1.getLong("AMOUNT");
	// // //System.out.print("\t\t " + amt + "\n");
	// // trnscDetBuffer.append("\t\t , " + amt + "\n");
	// //
	// // }
	// // // StringBuffer sb12 = new StringBuffer();
	// // bw.append(System.getProperty("line.separator"));
	// // // sb12.append(trans_date + "                 " + tot +
	// // "            "
	// // // + amt);
	// //
	// // bw.append(trnscDetBuffer.toString());
	// AccountSummaryModel acMo = new AccountSummaryModel();
	// bw.append(acMo.getTransactionSummary());
	//
	// // String trans_sql_bal =
	// // "SELECT ACCOUNT_BALANCE FROM ACCOUNT WHERE ACCOUNT_NUMBER=?";
	// // PreparedStatement ps2 =
	// // dbConnect.prepareStatement(trans_sql_bal);
	// // ps2.setLong(1, SessionManager.getAccountNumber());
	// // ResultSet rs2 = ps2.executeQuery();
	// // while (rs2.next())
	// // {
	// // long bal = rs2.getLong("ACCOUNT_BALANCE");
	// System.out.println(SessionManager.getAccountBalance());
	// StringBuffer sb8 = new StringBuffer();
	// bw.append(System.getProperty("line.separator"));
	// sb8.append("_________________________________________________________________________");
	// sb8.append("CURRENT BALANCE    " + bal);
	//
	// bw.append(sb8);
	// bw.append(System.getProperty("line.separator"));
	//
	// // }
	// // bwOutFile.flush();
	//
	// bw.close();
	// }
	// }

	private static Timestamp convertStringToTimestamp(String str_date)
	{

		try
		{
			DateFormat formatter;
			formatter = new SimpleDateFormat("dd/MMM/yyyy");
			// you can change format of date
			java.util.Date date = formatter.parse(str_date);
			java.sql.Timestamp timeStampDate = new Timestamp(date.getTime());

			return timeStampDate;

		} catch (ParseException e)

		{
			System.out.println("Exception :" + e);
			return convertStringToTimestamp(null);
		}

	}

}

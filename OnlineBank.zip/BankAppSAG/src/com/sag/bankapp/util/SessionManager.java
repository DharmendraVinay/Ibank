package com.sag.bankapp.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.sag.bankapp.constants.BankAppConstants;
import com.sag.bankapp.exception.SessionException;
import com.sag.bankapp.pojo.Account;
import com.sag.bankapp.pojo.User;

public class SessionManager
{

	public static User user;
	public static Account account;
	public static boolean isUserLoggedIn = false;
	public static Date lastActiveTimeStamp;

	public static String getUsername() throws SQLException
	{
		return user.getUserName();
	}

	/*
	 * public static String getLastName() throws SQLException { return
	 * user.getLastName(); }
	 * 
	 * public static Date getDOB() throws SQLException { return user.getDOB(); }
	 */
	public static Long getNumber() throws SQLException
	{
		return user.getNumber();
	}

	public static int getUserId()
	{
		return user.getUserId();
	}

	public static String getState() throws SQLException
	{
		return user.getState();
	}

	public static String getHouseNo() throws SQLException
	{
		return user.getHouseNo();
	}

	public static String getPlotNo() throws SQLException
	{
		return user.getPlotNo();
	}

	public static String getStreet() throws SQLException
	{
		return user.getStreet();
	}

	public static String getCity() throws SQLException
	{
		return user.getCity();
	}

	public static Long getAlternateNumber() throws SQLException
	{
		return user.getAlternateNumber();
	}

	public static String getFirstName() throws SQLException
	{
		return user.getFirstName();
	}

	public static String getLastName() throws SQLException
	{
		return user.getLastName();
	}

	public static Date getDOB() throws SQLException
	{
		return user.getDOB();
	}

	public static String getEmail() throws SQLException
	{
		return user.getEmail();
	}

	public static String getSecurityQuestion() throws SQLException
	{
		return user.getSecurityQuestion();
	}

	public static String getSecurityAnswer() throws SQLException
	{
		return user.getSecurityAnswer();
	}

	public static String getPassword() throws SQLException
	{
		return user.getPassword();
	}

	public static long getAccountNumber()
	{

		return account.getAccountNumber();
	}

	public static double getAccountBalance()
	{

		return account.getAccountBalnce();
	}

	public static void destroySession()
	{
		SessionManager.isUserLoggedIn = false;
		user = null;
		account = null;

	}

	public boolean isUserLoggedIn()
	{
		return isUserLoggedIn;
	}

	public static void startSession()
	{
		SessionManager.isUserLoggedIn = true;

	}

	// logout user if 10 minutes of idle activity is found
	public static void handleSessionExpiration() throws SessionException
	{
		long duration = new Date().getTime() - lastActiveTimeStamp.getTime();
		if (duration >= BankAppConstants.MAX_IDLE_DURATION)
		{
			throw new SessionException("Session Expired , login again");
		} else
		{
			lastActiveTimeStamp = new Date();
		}
	}

}

package com.sag.bankapp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Properties;

public class ProfileConnector
{

	public static AppProperties loadDriverProperties()
	{

		Properties prop = new Properties();
		InputStream input = null;
		
		AppProperties appProper = new AppProperties();

		try
		{

			input = new FileInputStream("C:\\config.properties");

			// load a properties file
			prop.load(input);

			appProper.setDriver(prop.getProperty("DB_DRIVER"));

			appProper.setConnection(prop.getProperty("DB_CONNECTION"));
			appProper.setDbuser(prop.getProperty("DB_USER"));
			appProper.setDbpassword(prop.getProperty("DB_PASSWORD"));

			// System.out.println(appProper);

		} catch (IOException ex)
		{
			ex.printStackTrace();
		} finally
		{
			if (input != null)
			{
				try
				{
					input.close();
				} catch (IOException e)
				{
					e.printStackTrace();
				}

			}

		}
		return appProper;

	}

}

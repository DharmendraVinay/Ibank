package com.sag.bankapp.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

// class to handle basic string function 
public class StringUtility
{

	// check if string contains white spaces
	public boolean containsWhiteSpace(final String testCode)
	{
		if (testCode != null)
		{
			for (int i = 0; i < testCode.length(); i++)
			{
				if (Character.isWhitespace(testCode.charAt(i)))
				{
					return true;
				}
			}
		}
		return false;
	}

	// checks if password matches to re typed password
	public boolean validatePassword(String password, String retypedPassword)
	{

		boolean status = password.equals(retypedPassword);
		if (status)
		{
			System.err
					.println("IOUtils -> Password and Retype password matches");
			status = true;

		} else
		{
			System.err
					.println("IOUtils -> Password and Retype password dont matches");
			status = false;
		}
		return status;

	}

	// https://www.mkyong.com/regular-expressions/how-to-validate-email-address-with-regular-expression/
	// check if email is valid
	public boolean isEmailValid(String email)
	{
		Pattern pattern;
		Matcher matcher;

		final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		pattern = Pattern.compile(EMAIL_PATTERN);

		/**
		 * Validate hex with regular expression
		 * 
		 * @param hex
		 *            hex for validation
		 * @return true valid hex, false invalid hex
		 */
		matcher = pattern.matcher(email);
		return matcher.matches();
	}
}
